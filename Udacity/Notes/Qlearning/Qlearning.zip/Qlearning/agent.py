import random
from environment import Agent, Environment
from planner import RoutePlanner
from simulator import Simulator
from collections import namedtuple

class QLearningAgent(Agent):
    def __init__(self, env):
        super(QLearningAgent, self).__init__(env) 
        self.color = 'black'
        self.planner = RoutePlanner(self.env, self) 

        self.qDict = dict()

        self.default_value = 10

        self.learning_rate = .1
        self.epsilon  = .1

        self.gamma = 0.35
        self.discount = self.gamma

        self.previous_state = None
        self.state = None
        self.previous_action = None

        self.deadline = self.env.get_deadline(self)       
        self.previous_reward = None

        self.total_reward = 0

        self.actions = ['forward', 'left', 'right', None]

    def reset(self, destination=None):
        self.planner.route_to(destination)
        self.previous_state = None
        self.state = None
        self.previous_action = None
        self.epsilon = .1
        self.total_reward = 0

    def getQValue(self, state, action):
        return self.qDict.get((state, action), self.default_value)

    def getValue(self, state):
        bestQValue = float('-inf')      
        for action in self.actions:
            if(self.getQValue(state, action) > bestQValue):
                bestQValue = self.getQValue(state, action)

        return bestQValue

    def getPolicy(self, state):
        bestAction = None
        bestQValue = float('-inf')
        for action in self.actions:
            if(self.getQValue(state, action) > bestQValue):
                bestQValue = self.getQValue(state, action)
                bestAction = action
            elif self.getQValue(state,action) == bestQValue:
                action = random.choice(self.actions)

        return bestAction

    def create_state(self, state):
        State = namedtuple("State", ["light","next_waypoint"])
        return State(light = state['light'],
                        next_waypoint = self.planner.next_waypoint())
 

    def update(self, t):
        self.next_waypoint = self.planner.next_waypoint()
        inputs = self.env.sense(self)
        self.state = self.create_state(inputs)

        action = self.getAction(self.state)

        reward = self.env.act(self, action)

        if self.previous_reward!= None:
            self.updateQTable(self.previous_state,self.previous_action,
                self.state,self.previous_reward)

        self.previous_action = action
        self.previous_state = self.state
        self.previous_reward = reward
        self.total_reward += reward

    def getAction(self, state):
        action = None
        a = random.random()
        print a
        print self.epsilon
        if float(a) < float(self.epsilon):
            print "random choice"
            action = random.choice(self.actions)
        else:
            print "policy choice"
            action = self.getPolicy(state)
        return action

    def updateQTable(self, state, action, nextState, reward):
        if((state, action) not in self.qDict): 
            self.qDict[(state, action)] = self.default_value
        else:
            self.qDict[(state, action)] = self.qDict[(state, action)] + \
            (1-self.learning_rate) * \
            (reward + self.discount * self.getValue(nextState) -   self.qDict[(state, action)])

class LearningAgent(Agent):
    """An agent that learns to drive in the smartcab world."""

    def __init__(self, env):
        
        super(LearningAgent, self).__init__(env)  # sets self.env = env, state = None, next_waypoint = None, and a default color
        
        self.color = 'black'  # override color
        self.planner = RoutePlanner(self.env, self)  # simple route planner to get next_waypoint
       
        # TODO: Initialize any additional variables here
        self.previous_reward = 0
        self.previous_action = None

    def reset(self, destination=None):
        self.planner.route_to(destination)

        # TODO: Prepare for a new trip; reset any variables here, if required
        self.previous_reward = 0
        self.previous_action = None
        self.state = None

    def update(self, t):

        # Gather inputs
        self.next_waypoint = self.planner.next_waypoint()  # from route planner, also displayed by simulator
        inputs = self.env.sense(self)
        deadline = self.env.get_deadline(self)

        print inputs

        # TODO: Update state
        if self.state == None:
			self.state = 'running'       

        # TODO: Select action according to your policy
        action = None

        arr = []
        if inputs['light'] == 'red':
        	if inputs['oncoming'] != 'left':
        		arr = ['right', None]

        if inputs['light'] == 'green':
        	if inputs['oncoming'] == 'forward':
        		arr = ['right', 'forward']
        	else:
        		arr = ['right','forward','left']

        print arr

        flag = False
        if arr != []:
        	flag = True

        print self.state

        if flag and self.state == 'running':
        	action = random.choice(arr)
        elif flag and self.state == 'reset':
        	action = self.previous_action


        print action

        # Execute action and get reward
        reward = self.env.act(self, action)

        # TODO: Learn policy based on state, action, reward

        if action != None:
        	if reward > self.previous_reward:
        		self.state = 'reset'
        	else:
        		self.state = 'running'
        	self.previous_action = action
        	self.previous_reward = reward

        print "LearningAgent.update(): deadline = {}, inputs = {}, action = {}, reward = {}".format(deadline, inputs, action, reward)  # [debug]


def run():
    """Run the agent for a finite number of trials."""

    # Set up environment and agent
    e = Environment()  # create environment (also adds some dummy traffic)
    

    a = e.create_agent(QLearningAgent)  # create agent
    e.set_primary_agent(a, enforce_deadline=True)  # set agent to track


    # Now simulate it
    sim = Simulator(e, update_delay=.00000001)  # reduce update_delay to speed up simulation
    sim.run(n_trials=100)  # press Esc or close pygame window to quit

    print "Couldn't reach", e.counter1
    print "Reached", e.counter2    


if __name__ == '__main__':
    run()
